const express = require('express');
const mongoose = require('mongoose');
const app = express();
const PORT = process.env.PORT || 8090;
const itemRoutes = require('./routes/items');

// Use routes



// Middleware to parse JSON bodies
app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb+srv://susmithr1810:<abcd1234>@cluster0.4diizpf.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.log(err));
app.use('/items', itemRoutes);
// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});








