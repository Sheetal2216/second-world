function addNumber(a,b){
    return a+b
}
function subtractNumber(a,b){
    return a-b
}
function mulNumber(a,b){
    return a*b
}

function divNumber(a,b){
    return a/b

}

module.exports={addNumber,subtractNumber,mulNumber,divNumber}
