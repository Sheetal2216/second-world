const express=require('express');
const dotEnv=require(' dotEnv');
const {Mongoclient}=require("mongodb");
const app=express();
const port=5000
dotEnv.config()

Mongoclient.connect(proccess.env.MONGO_URI)
.then(()=>{
    console.log("connected")
})
.catch((error)=>{
    console.log("error,error")
})

console.log(process.env)
app.listen(port,()=>{
    console.log("server started at ${port}")
})